﻿using Microsoft.Extensions.DependencyInjection;
using StudentClinicMIS.Data.Interfaces;
using StudentClinicMIS.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace StudentClinicMIS.Views.Registrar
{
    public partial class AppointmentPanel : UserControl
    {
        public AppointmentPanel()
        {
            InitializeComponent();
            Loaded += async (s, e) => await LoadInitialDataAsync();
        }

        private async Task LoadInitialDataAsync()
        {
            using var scope = App.AppHost.Services.CreateScope();
            var patientRepository = scope.ServiceProvider.GetRequiredService<IPatientRepository>();
            var doctorRepository = scope.ServiceProvider.GetRequiredService<IDoctorRepository>();
            var context = scope.ServiceProvider.GetRequiredService<PolyclinicContext>();

            var patients = await patientRepository.GetAllAsync();
            var departments = context.Departments.ToList();

            PatientComboBox.ItemsSource = patients.OrderBy(p => p.LastName).Select(p => new
            {
                p.PatientId,
                FullName = $"{p.LastName} {p.FirstName} {p.MiddleName}"
            }).ToList();

            DepartmentComboBox.ItemsSource = departments;
        }

        private async void DepartmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DoctorComboBox.ItemsSource = null;

            if (DepartmentComboBox.SelectedItem is Department selectedDepartment)
            {
                using var scope = App.AppHost.Services.CreateScope();
                var doctorRepository = scope.ServiceProvider.GetRequiredService<IDoctorRepository>();

                var doctors = await doctorRepository.GetByDepartmentIdAsync(selectedDepartment.DepartmentId);

                DoctorComboBox.ItemsSource = doctors.Select(d => new
                {
                    d.DoctorId,
                    FullName = $"{d.Employee.LastName} {d.Employee.FirstName} {d.Employee.MiddleName}"
                }).ToList();
            }
        }

        private async void DoctorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            await UpdateAvailableSlotsAsync();
        }

        private async void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            await UpdateAvailableSlotsAsync();
        }

        private async Task UpdateAvailableSlotsAsync()
        {
            TimeSlotsListBox.ItemsSource = null;

            if (DoctorComboBox.SelectedValue == null || DatePicker.SelectedDate == null)
                return;

            int doctorId = (int)DoctorComboBox.SelectedValue;
            var date = DateOnly.FromDateTime(DatePicker.SelectedDate.Value);

            using var scope = App.AppHost.Services.CreateScope();
            var appointmentRepository = scope.ServiceProvider.GetRequiredService<IAppointmentRepository>();

            var appointments = await appointmentRepository.GetAppointmentsByDoctorAndDateAsync(doctorId, date);
            var slots = GenerateTimeSlots("09:00", "15:00", TimeSpan.FromMinutes(30));

            var slotItems = slots.Select(slot => new TimeSlotDisplay
            {
                Time = slot,
                Display = slot.ToString("HH:mm"),
                IsOccupied = appointments.Any(a => a.StartTime == slot)
            }).ToList();

            TimeSlotsListBox.ItemsSource = slotItems;
        }

        private List<TimeOnly> GenerateTimeSlots(string from, string to, TimeSpan step)
        {
            var slots = new List<TimeOnly>();
            var start = TimeOnly.ParseExact(from, "HH:mm", CultureInfo.InvariantCulture);
            var end = TimeOnly.ParseExact(to, "HH:mm", CultureInfo.InvariantCulture);

            while (start < end)
            {
                slots.Add(start);
                start = start.Add(step);
            }

            return slots;
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (PatientComboBox.SelectedValue is not int patientId ||
                DoctorComboBox.SelectedValue is not int doctorId ||
                DatePicker.SelectedDate is null ||
                TimeSlotsListBox.SelectedItem is not TimeSlotDisplay selectedSlot ||
                selectedSlot.IsOccupied)
            {
                MessageBox.Show("Пожалуйста, выберите пациента и свободный слот.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var appointment = new Appointment
            {
                PatientId = patientId,
                DoctorId = doctorId,
                AppointmentDate = DateOnly.FromDateTime(DatePicker.SelectedDate.Value),
                StartTime = selectedSlot.Time,
                Status = "Запланирован",
                CreatedAt = DateTime.Now
            };

            using var scope = App.AppHost.Services.CreateScope();
            var appointmentRepository = scope.ServiceProvider.GetRequiredService<IAppointmentRepository>();

            await appointmentRepository.AddAsync(appointment);

            MessageBox.Show("Пациент записан на приём.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            await UpdateAvailableSlotsAsync();
        }

        private class TimeSlotDisplay
        {
            public TimeOnly Time { get; set; }
            public string Display { get; set; }
            public bool IsOccupied { get; set; }
        }
    }
}
