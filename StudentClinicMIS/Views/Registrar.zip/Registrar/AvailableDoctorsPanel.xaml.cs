﻿using StudentClinicMIS.Data.Interfaces;
using StudentClinicMIS.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace StudentClinicMIS.Views.Registrar
{
    public partial class AvailableDoctorsPanel : UserControl
    {
        private readonly IAppointmentRepository _appointmentRepository;
        private readonly IDepartmentRepository _departmentRepository;
        private readonly IDoctorRepository _doctorRepository;

        public Patient? CurrentPatient { get; set; }

        private ObservableCollection<Department> _departments = new();
        private ObservableCollection<Doctor> _doctors = new();
        private ObservableCollection<AppointmentSlot> _slots = new();

        public AvailableDoctorsPanel()
        {
            InitializeComponent();

            _appointmentRepository = (IAppointmentRepository)App.AppHost.Services.GetService(typeof(IAppointmentRepository))!;
            _departmentRepository = (IDepartmentRepository)App.AppHost.Services.GetService(typeof(IDepartmentRepository))!;
            _doctorRepository = (IDoctorRepository)App.AppHost.Services.GetService(typeof(IDoctorRepository))!;

            DepartmentComboBox.ItemsSource = _departments;
            DoctorComboBox.ItemsSource = _doctors;
            TimeSlotsListBox.ItemsSource = _slots;

            Loaded += async (s, e) => await LoadDepartmentsAsync();
        }

        public void UpdatePatientInfo()
        {
            if (CurrentPatient != null)
            {
                // отобразить пациента (если нужно)
            }
        }

        private async Task LoadDepartmentsAsync()
        {
            try
            {
                var list = await _departmentRepository.GetAllAsync();
                _departments.Clear();
                foreach (var dep in list)
                    _departments.Add(dep);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки отделений: {ex.Message}");
            }
        }

        private async void DepartmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DepartmentComboBox.SelectedItem is Department selectedDepartment)
            {
                await LoadDoctorsByDepartmentAsync(selectedDepartment.DepartmentId);
            }
        }

        private async Task LoadDoctorsByDepartmentAsync(int departmentId)
        {
            try
            {
                var list = await _doctorRepository.GetByDepartmentIdAsync(departmentId);
                _doctors.Clear();
                foreach (var doctor in list)
                    _doctors.Add(doctor);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки врачей: {ex.Message}");
            }
        }

        private async void DoctorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            await LoadSlotsAsync();
        }

        private async void AppointmentDatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            await LoadSlotsAsync();
        }

        private async Task LoadSlotsAsync()
        {
            _slots.Clear();

            if (DoctorComboBox.SelectedItem is not Doctor doctor ||
                AppointmentDatePicker.SelectedDate is not DateTime selectedDate)
                return;

            var dateOnly = DateOnly.FromDateTime(selectedDate);

            var appointments = await _appointmentRepository.GetAppointmentsByDoctorAndDateAsync(doctor.DoctorId, dateOnly);

            var schedule = await _doctorRepository.GetScheduleForDoctorAsync(doctor.DoctorId, dateOnly.DayOfWeek);

            if (schedule is null)
                return;

            var start = schedule.StartTime;
            var end = schedule.EndTime;

            var interval = TimeSpan.FromMinutes(30);
            for (var time = start; time < end; time = time.Add(interval))
            {
                bool occupied = appointments.Any(a => a.StartTime == time);

                _slots.Add(new AppointmentSlot
                {
                    StartTime = time,
                    IsOccupied = occupied
                });
            }
        }

        private void SlotButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is AppointmentSlot slot)
            {
                TimeSlotsListBox.SelectedItem = slot;
            }
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPatient == null)
            {
                MessageBox.Show("Пациент не выбран.");
                return;
            }

            if (DoctorComboBox.SelectedItem is not Doctor doctor ||
                AppointmentDatePicker.SelectedDate is not DateTime date ||
                TimeSlotsListBox.SelectedItem is not AppointmentSlot slot)
            {
                MessageBox.Show("Выберите врача, дату и время.");
                return;
            }

            var appointment = new Appointment
            {
                PatientId = CurrentPatient.PatientId,
                DoctorId = doctor.DoctorId,
                AppointmentDate = DateOnly.FromDateTime(date),
                StartTime = slot.StartTime,
                Status = "Запланирован",
                CreatedAt = DateTime.Now
            };

            try
            {
                await _appointmentRepository.AddAsync(appointment);
                MessageBox.Show("Запись успешно создана.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                await LoadSlotsAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }
    }

    public class AppointmentSlot
    {
        public TimeOnly StartTime { get; set; }
        public bool IsOccupied { get; set; }
        public string Display => StartTime.ToString("HH:mm");
    }
}
